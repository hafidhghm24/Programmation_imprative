#include <stdio.h>
#include "element.h"

int main(){
	int elm;
	saisir_ELEMENT



}
