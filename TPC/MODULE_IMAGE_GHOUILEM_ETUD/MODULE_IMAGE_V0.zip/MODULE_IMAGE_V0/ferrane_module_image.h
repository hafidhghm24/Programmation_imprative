#ifndef MODULE_IMAGE_H_INCLUS     /*--  Inclusion conditionnelle --> si pas déjà inclus           */
#define MODULE_IMAGE_H_INCLUS     /*--  alors créer la constante symbolique MODULE_IMAGE_H_INCLUS */

/* AUTEUR : ISABELLE FERRANE                       */
/* DATE CREATION : 11/10/2018                      */
/*-------------------------------------------------*/

/* DECLARATIONS DES FONCTIONS */

void test_prog(void);

#endif
