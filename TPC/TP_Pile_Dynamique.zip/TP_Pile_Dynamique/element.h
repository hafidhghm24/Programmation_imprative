#ifndef TP_PILE_STATIQUE_P1
#define TP_PILE_STATIQUE_P1

	/* definir le type element */
	typedef int ELEMENT;
	
	/* prototype des fonctions */
	
	void affiche_ELEMENT(ELEMENT element);
	void saisir_ELEMENT(ELEMENT* ptr_elm);
	void compare_ELEMENT(ELEMENT* ptr_elm1, ELEMENT* ptr_elm2);
	void affect_ELEMENT(ELEMENT ptr_elm1, ELEMENT* ptr_elm2);



#endif
