#include <stdio.h>
#include <stdlib.h>
#include "ferrane_module_image.h"


/* AUTEUR : ISABELLE FERRANE                       */
/* DATE CREATION : 11/10/2018                      */
/*-------------------------------------------------*/

/* DEFINITIONS DES FONCTIONS déclarées dans le .h */

void test_prog(void)
{ 	
	printf("TEST DU MODULE : FERRANE_MODULE_IMAGE\n");
	
}

