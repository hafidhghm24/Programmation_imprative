#ifndef MODULE_IMAGE_H_INCLUS     /*--  Inclusion conditionnelle --> si pas déjà inclus           */
#define MODULE_IMAGE_H_INCLUS     /*--  alors créer la constante symbolique MODULE_IMAGE_H_INCLUS */

/* AUTEUR : GHOUILEM Abdelhafidh                      */
/* DATE CREATION : 07/11/2025                      */
/*-------------------------------------------------*/

/* DECLARATIONS DES FONCTIONS */

void test_prog(void);
int afficher_image_codee(int niv);
#endif
